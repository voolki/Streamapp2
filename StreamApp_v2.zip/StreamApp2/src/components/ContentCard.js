import React from 'react';
import { TouchableOpacity, View, Text, StyleSheet } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { C } from '../theme';

export default function ContentCard({ item, onPress, cardWidth = 150 }) {
  return (
    <TouchableOpacity style={[styles.card, { width: cardWidth }]} onPress={() => onPress(item)} activeOpacity={0.8}>
      <LinearGradient colors={item.grad || ['#1a1a2a','#0a0a1a']} style={styles.thumb} start={{x:0,y:0}} end={{x:1,y:1}}>
        <Text style={styles.emoji}>{item.emoji}</Text>
        {item.isNew && <View style={styles.badgeNew}><Text style={styles.badgeTxt}>YENİ</Text></View>}
        {item.isTop && <View style={styles.badgeTop}><Text style={[styles.badgeTxt,{color:C.gold}]}>TOP 10</Text></View>}
      </LinearGradient>
      <View style={styles.info}>
        <Text style={styles.title} numberOfLines={1}>{item.title}</Text>
        <View style={styles.row}>
          <Text style={styles.year}>{item.year}</Text>
          {item.rating ? <Text style={styles.star}> · ★ {item.rating}</Text> : null}
        </View>
      </View>
    </TouchableOpacity>
  );
}

const s = StyleSheet.create({});
const styles = StyleSheet.create({
  card:     { backgroundColor:C.surface, borderRadius:10, overflow:'hidden', borderWidth:1, borderColor:C.border, marginRight:12 },
  thumb:    { aspectRatio:2/3, alignItems:'center', justifyContent:'center' },
  emoji:    { fontSize:38 },
  badgeNew: { position:'absolute', top:6, left:6, backgroundColor:C.accent, paddingHorizontal:6, paddingVertical:2, borderRadius:4 },
  badgeTop: { position:'absolute', top:6, right:6, backgroundColor:'rgba(244,162,97,0.2)', borderWidth:1, borderColor:C.gold, paddingHorizontal:6, paddingVertical:2, borderRadius:4 },
  badgeTxt: { fontSize:8, fontWeight:'800', color:'#fff' },
  info:     { padding:8 },
  title:    { fontSize:12, fontWeight:'600', color:C.text },
  row:      { flexDirection:'row', marginTop:3 },
  year:     { fontSize:11, color:C.text3 },
  star:     { fontSize:11, color:C.gold },
});
