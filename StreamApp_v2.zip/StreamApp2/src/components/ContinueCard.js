import React from 'react';
import { TouchableOpacity, View, Text, StyleSheet } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { C } from '../theme';

export default function ContinueCard({ item, onPress }) {
  return (
    <TouchableOpacity style={styles.card} onPress={() => onPress(item)} activeOpacity={0.8}>
      <LinearGradient colors={item.grad||['#1a1a2a','#0a0a1a']} style={styles.bg} start={{x:0,y:0}} end={{x:1,y:1}}>
        <Text style={styles.emoji}>{item.emoji}</Text>
        <LinearGradient colors={['transparent','rgba(10,10,15,0.95)']} style={styles.fade} />
        <View style={styles.play}><Text style={{color:'#fff',fontSize:14}}>▶</Text></View>
      </LinearGradient>
      <View style={styles.info}>
        <Text style={styles.title} numberOfLines={1}>{item.title}</Text>
        <Text style={styles.sub} numberOfLines={1}>{item.sub}</Text>
        <View style={styles.barBg}><View style={[styles.barFill,{width:`${item.progress*100}%`}]} /></View>
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  card:  { width:240, backgroundColor:C.surface, borderRadius:10, overflow:'hidden', borderWidth:1, borderColor:C.border, marginRight:12 },
  bg:    { height:130, alignItems:'center', justifyContent:'center' },
  emoji: { fontSize:42 },
  fade:  { position:'absolute', bottom:0, left:0, right:0, height:60 },
  play:  { position:'absolute', width:40, height:40, borderRadius:20, backgroundColor:'rgba(230,57,70,0.9)', alignItems:'center', justifyContent:'center' },
  info:  { padding:10 },
  title: { fontSize:13, fontWeight:'600', color:C.text },
  sub:   { fontSize:11, color:C.text2, marginTop:2 },
  barBg: { height:3, backgroundColor:'rgba(255,255,255,0.12)', borderRadius:99, marginTop:8, overflow:'hidden' },
  barFill:{ height:'100%', backgroundColor:C.accent, borderRadius:99 },
});
