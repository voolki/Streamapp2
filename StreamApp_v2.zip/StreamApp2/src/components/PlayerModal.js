import React, { useState } from 'react';
import { Modal, View, Text, TouchableOpacity, StyleSheet, Dimensions, ScrollView } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { C } from '../theme';

const { height } = Dimensions.get('window');

export default function PlayerModal({ item, visible, onClose }) {
  const [playing, setPlaying] = useState(false);
  const [progress, setProgress] = useState(0.35);
  if (!item) return null;

  return (
    <Modal visible={visible} animationType="slide" transparent onRequestClose={onClose}>
      <View style={styles.overlay}>
        <View style={styles.modal}>

          {/* Player */}
          <View style={styles.playerArea}>
            <LinearGradient colors={item.grad||['#0d1520','#1a0a2e']} style={StyleSheet.absoluteFill} start={{x:0,y:0}} end={{x:1,y:1}}>
              <View style={{flex:1,alignItems:'center',justifyContent:'center'}}>
                <Text style={{fontSize:72}}>{item.emoji}</Text>
              </View>
            </LinearGradient>
            <LinearGradient colors={['transparent','rgba(0,0,0,0.95)']} style={styles.controls}>
              <View style={styles.seekBg}><View style={[styles.seekFill,{width:`${progress*100}%`}]}/></View>
              <View style={styles.ctrlRow}>
                <TouchableOpacity onPress={()=>setProgress(Math.max(0,progress-0.1))}><Text style={styles.ci}>⏮</Text></TouchableOpacity>
                <TouchableOpacity onPress={()=>setPlaying(!playing)}><Text style={[styles.ci,{fontSize:32}]}>{playing?'⏸':'▶'}</Text></TouchableOpacity>
                <TouchableOpacity onPress={()=>setProgress(Math.min(1,progress+0.1))}><Text style={styles.ci}>⏭</Text></TouchableOpacity>
                <Text style={styles.timeT}>35:22 / 1:18:44</Text>
              </View>
            </LinearGradient>
            <TouchableOpacity style={styles.closeBtn} onPress={onClose}>
              <Text style={{color:'#fff',fontSize:16}}>✕</Text>
            </TouchableOpacity>
          </View>

          {/* Info */}
          <ScrollView style={styles.info} showsVerticalScrollIndicator={false}>
            <Text style={styles.infoTitle}>{item.title}</Text>
            <View style={styles.metaRow}>
              {item.rating&&<Text style={styles.rat}>★ {item.rating}  </Text>}
              <Text style={styles.metaTxt}>{item.year} · {item.duration}</Text>
            </View>
            <Text style={styles.genre}>{item.genre}</Text>
            <Text style={styles.desc}>{item.desc}</Text>
            <View style={styles.actionRow}>
              {[['♥','Favori'],['↓','İndir'],['⋯','Daha']].map(([ic,lb])=>(
                <TouchableOpacity key={lb} style={styles.actionBtn}>
                  <Text style={styles.actionIc}>{ic}</Text>
                  <Text style={styles.actionLb}>{lb}</Text>
                </TouchableOpacity>
              ))}
            </View>
            <Text style={styles.srcLabel}>Kaynak Seç</Text>
            <ScrollView horizontal showsHorizontalScrollIndicator={false}>
              {['Dizipal','HDFilmCehennemi','Sinefy'].map((s,i)=>(
                <TouchableOpacity key={s} style={[styles.srcBtn,i===0&&styles.srcBtnOn]}>
                  <Text style={[styles.srcTxt,i===0&&{color:C.accent,fontWeight:'600'}]}>{s}</Text>
                </TouchableOpacity>
              ))}
            </ScrollView>
            <View style={{height:30}}/>
          </ScrollView>
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay:    { flex:1, backgroundColor:'rgba(0,0,0,0.85)', justifyContent:'flex-end' },
  modal:      { backgroundColor:C.bg2, borderTopLeftRadius:20, borderTopRightRadius:20, overflow:'hidden', maxHeight:height*0.9 },
  playerArea: { height:220, position:'relative' },
  controls:   { position:'absolute', bottom:0, left:0, right:0, padding:14, paddingTop:40 },
  seekBg:     { height:4, backgroundColor:'rgba(255,255,255,0.2)', borderRadius:99, marginBottom:12, overflow:'hidden' },
  seekFill:   { height:'100%', backgroundColor:C.accent, borderRadius:99 },
  ctrlRow:    { flexDirection:'row', alignItems:'center', gap:14 },
  ci:         { color:'#fff', fontSize:22 },
  timeT:      { fontSize:12, color:'rgba(255,255,255,0.6)', marginLeft:4 },
  closeBtn:   { position:'absolute', top:12, right:12, width:32, height:32, borderRadius:16, backgroundColor:'rgba(0,0,0,0.6)', alignItems:'center', justifyContent:'center' },
  info:       { padding:20, maxHeight:320 },
  infoTitle:  { fontSize:22, fontWeight:'800', color:C.text, marginBottom:8 },
  metaRow:    { flexDirection:'row', alignItems:'center', marginBottom:6 },
  rat:        { color:C.gold, fontWeight:'700', fontSize:13 },
  metaTxt:    { fontSize:13, color:C.text2 },
  genre:      { fontSize:12, color:C.accent, fontWeight:'600', marginBottom:10 },
  desc:       { fontSize:14, color:C.text2, lineHeight:22, marginBottom:20 },
  actionRow:  { flexDirection:'row', gap:28, marginBottom:20 },
  actionBtn:  { alignItems:'center', gap:4 },
  actionIc:   { fontSize:22, color:C.text },
  actionLb:   { fontSize:11, color:C.text2 },
  srcLabel:   { fontSize:13, fontWeight:'600', color:C.text, marginBottom:10 },
  srcBtn:     { paddingHorizontal:16, paddingVertical:8, borderRadius:99, borderWidth:1, borderColor:C.border, marginRight:8, backgroundColor:C.surface },
  srcBtnOn:   { borderColor:C.accent, backgroundColor:'rgba(230,57,70,0.15)' },
  srcTxt:     { fontSize:12, color:C.text2 },
});
