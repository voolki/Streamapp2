export const TRENDING = [
  { id:'t1', title:'Karanlıktaki Sürgün', emoji:'🎬', year:'2024', rating:9.1, genre:'Aksiyon, Dram',    duration:'2s 18dk', desc:'Onlarca yıl sürgünde yaşayan eski bir ajan son bir göreve çağrılır.', grad:['#1a0a2e','#0d1b2a'], isNew:true,  isTop:false },
  { id:'t2', title:'Yıldız Savaşları',   emoji:'🚀', year:'2024', rating:8.7, genre:'Bilim Kurgu',       duration:'2s 05dk', desc:'Galaksinin kaderini belirleyecek son savaş başlıyor.',              grad:['#0a1628','#1a0a2e'], isNew:false, isTop:true  },
  { id:'t3', title:'Çukur',              emoji:'🏙️', year:'2023', rating:9.3, genre:'Dram, Suç',         duration:'S4 B45',  desc:'İstanbul\'un en karanlık semtinde derin bir aile hikayesi.',       grad:['#1a2a1a','#0a1a0a'], isNew:false, isTop:true  },
  { id:'t4', title:'Ezel',               emoji:'♠️', year:'2009', rating:9.5, genre:'Aksiyon, Gerilim',  duration:'S1-3',    desc:'İhanete uğrayan bir adamın intikam yolculuğu.',                   grad:['#2a0a0a','#0a0a2a'], isNew:false, isTop:true  },
  { id:'t5', title:'Interstellar',       emoji:'🌌', year:'2014', rating:8.6, genre:'Bilim Kurgu',       duration:'2s 49dk', desc:'İnsanlığın geleceği için uzayın derinliklerine yolculuk.',         grad:['#0a0a2a','#0a1a2a'], isNew:false, isTop:false },
  { id:'t6', title:'The Dark Knight',    emoji:'🦇', year:'2008', rating:9.0, genre:'Aksiyon, Suç',     duration:'2s 32dk', desc:'Batman, Gotham\'ı kaosa sürüklemek isteyen Joker ile karşı karşıya.',grad:['#0a0a0a','#1a1a2a'],isNew:false, isTop:true  },
  { id:'t7', title:'Diriliş: Ertuğrul', emoji:'⚔️', year:'2014', rating:8.9, genre:'Tarih, Macera',    duration:'S1-5',    desc:'Osmanlı\'nın kuruluşuna giden yolda Ertuğrul Bey\'in mücadelesi.', grad:['#1a0a0a','#2a1a0a'], isNew:false, isTop:false },
  { id:'t8', title:'Gladiator II',       emoji:'🛡️', year:'2024', rating:7.8, genre:'Aksiyon, Tarih',  duration:'2s 28dk', desc:'Roma\'nın kanlı arenalarında yeni bir savaşçı yükseliyor.',         grad:['#2a1a0a','#1a0a0a'], isNew:true,  isTop:false },
];

export const ANIME = [
  { id:'a1', title:'Attack on Titan',     emoji:'⚔️', year:'2013', rating:9.0, genre:'Anime, Aksiyon', duration:'Final Season', desc:'İnsanlık devlerin işgaline karşı son mücadelesini veriyor.',            grad:['#2a1a0a','#1a0a0a'], isNew:false, isTop:true  },
  { id:'a2', title:'Fullmetal Alchemist', emoji:'⚗️', year:'2009', rating:9.1, genre:'Anime, Fantezi', duration:'64 Bölüm',     desc:'İki kardeş annelerini geri getirmek için simyanın sınırlarını zorluyor.',grad:['#1a1a0a','#2a0a0a'], isNew:false, isTop:false },
  { id:'a3', title:'Demon Slayer',        emoji:'🗡️', year:'2019', rating:8.7, genre:'Anime, Aksiyon', duration:'S4 Devam',     desc:'Ailesini katleden iblislere karşı savaşan genç bir demon avcısı.',       grad:['#0a0a2a','#2a0a0a'], isNew:true,  isTop:false },
  { id:'a4', title:'Death Note',          emoji:'📓', year:'2006', rating:9.0, genre:'Anime, Gerilim', duration:'37 Bölüm',     desc:'Adını yazdığı kişiyi öldüren defteri bulan zeki bir öğrenci.',            grad:['#0a0a0a','#1a0a1a'], isNew:false, isTop:true  },
  { id:'a5', title:'Jujutsu Kaisen',      emoji:'💀', year:'2020', rating:8.6, genre:'Anime, Fantezi', duration:'S3 Devam',     desc:'Lanetli ruhlarla savaşan genç büyücünün macerası.',                      grad:['#0a1a0a','#1a0a2a'], isNew:true,  isTop:false },
];

export const MUSIC = [
  { id:'m1', title:'Tarkan: Ben Aşık Oldum', emoji:'🎵', year:'2024', rating:null, genre:'Pop, Türkçe',    duration:'Album', desc:'Tarkan\'ın yeni albümünden öne çıkan parçalar.', grad:['#1a0a2a','#0a1a1a'], isNew:true,  isTop:false },
  { id:'m2', title:'Dizi Müzikleri Podcast', emoji:'🎙️', year:'2024', rating:null, genre:'Podcast',         duration:'45dk',  desc:'En sevilen Türk dizi müziklerinin perde arkası.', grad:['#0a1a2a','#1a1a0a'], isNew:false, isTop:false },
  { id:'m3', title:'Türk Rock Tarihi',       emoji:'🎸', year:'2023', rating:null, genre:'Belgesel, Müzik', duration:'1s 20dk',desc:'70\'lerden günümüze Türk rock müziğinin evrimi.', grad:['#2a0a0a','#1a1a0a'], isNew:false, isTop:false },
  { id:'m4', title:'Caz Geceleri',           emoji:'🎷', year:'2024', rating:null, genre:'Canlı, Caz',     duration:'2s 10dk',desc:'İstanbul\'un efsanevi caz barlarından performanslar.', grad:['#0a0a1a','#1a0a2a'], isNew:true, isTop:false },
];

export const CONTINUE_WATCHING = [
  { id:'c1', title:'Çukur',          sub:'S4 Bölüm 12 · 23dk kaldı', progress:0.68, emoji:'🏙️', grad:['#1a2a1a','#0a1a0a'] },
  { id:'c2', title:'Attack on Titan',sub:'Final · 8dk kaldı',         progress:0.90, emoji:'⚔️', grad:['#2a1a0a','#1a0a0a'] },
  { id:'c3', title:'Inception',      sub:'Film · 45dk kaldı',         progress:0.42, emoji:'🌀', grad:['#0a1a2a','#0a0a1a'] },
  { id:'c4', title:'Caz Geceleri',   sub:'Belgesel · 12dk kaldı',     progress:0.80, emoji:'🎵', grad:['#0a0a1a','#1a0a2a'] },
];

export const PLUGINS = [
  { id:'p1', name:'Dizipal',         icon:'📺', desc:'Türkçe güncel diziler',  count:'1200+ içerik', active:true  },
  { id:'p2', name:'HDFilmCehennemi', icon:'🎬', desc:'HD kaliteli filmler',    count:'3000+ film',   active:true  },
  { id:'p3', name:'AnimeTürk',       icon:'⚔️', desc:'Türkçe dublaj anime',   count:'500+ anime',   active:true  },
  { id:'p4', name:'Dizilla',         icon:'📡', desc:'Canlı yayın dizileri',   count:'800+ dizi',    active:false },
  { id:'p5', name:'Sinefy',          icon:'🎥', desc:'Film & dizi platformu',  count:'2000+ içerik', active:true  },
  { id:'p6', name:'MüzikTR',         icon:'🎵', desc:'Yerli müzik arşivi',     count:'10000+ parça', active:false },
];
