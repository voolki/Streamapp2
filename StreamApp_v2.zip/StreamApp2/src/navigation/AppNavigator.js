import React from 'react';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Text } from 'react-native';
import { C } from '../theme';
import HomeScreen      from '../screens/HomeScreen';
import SearchScreen    from '../screens/SearchScreen';
import FavoritesScreen from '../screens/FavoritesScreen';
import PluginsScreen   from '../screens/PluginsScreen';
import ProfileScreen   from '../screens/ProfileScreen';

const Tab = createBottomTabNavigator();
const ICONS = { Ana:['⌂','⌂'], Keşfet:['⌕','⌕'], Favoriler:['♡','♥'], Pluginler:['⊞','⊞'], Profil:['◎','◎'] };

export default function AppNavigator() {
  return (
    <Tab.Navigator screenOptions={({route})=>({
      headerShown: false,
      tabBarStyle: { backgroundColor:C.bg2, borderTopColor:C.border, height:64, paddingBottom:10 },
      tabBarActiveTintColor: C.accent,
      tabBarInactiveTintColor: C.text3,
      tabBarLabel: ({focused,color}) => <Text style={{fontSize:10,color,fontWeight:focused?'700':'400'}}>{route.name}</Text>,
      tabBarIcon:  ({focused,color}) => <Text style={{fontSize:22,color}}>{focused?ICONS[route.name][1]:ICONS[route.name][0]}</Text>,
    })}>
      <Tab.Screen name="Ana"       component={HomeScreen}/>
      <Tab.Screen name="Keşfet"    component={SearchScreen}/>
      <Tab.Screen name="Favoriler" component={FavoritesScreen}/>
      <Tab.Screen name="Pluginler" component={PluginsScreen}/>
      <Tab.Screen name="Profil"    component={ProfileScreen}/>
    </Tab.Navigator>
  );
}
