import React, { useState, useCallback } from 'react';
import { View, Text, FlatList, StyleSheet, Dimensions } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useFocusEffect } from '@react-navigation/native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { C } from '../theme';
import ContentCard from '../components/ContentCard';
import PlayerModal from '../components/PlayerModal';

const { width } = Dimensions.get('window');
const CARD_W = (width - 48) / 3;

export default function FavoritesScreen() {
  const insets = useSafeAreaInsets();
  const [favs, setFavs] = useState([]);
  const [activeItem, setActiveItem] = useState(null);
  const [playerVisible, setPlayerVisible] = useState(false);

  useFocusEffect(useCallback(() => {
    AsyncStorage.getItem('streamapp_favorites').then(d => setFavs(d ? JSON.parse(d) : []));
  }, []));

  const open = (item) => { setActiveItem(item); setPlayerVisible(true); };

  return (
    <View style={[styles.root,{paddingTop:insets.top}]}>
      <Text style={styles.title}>Favorilerim <Text style={{color:C.accent}}>♥</Text></Text>
      {favs.length===0 ? (
        <View style={styles.empty}>
          <Text style={{fontSize:60,opacity:0.3,marginBottom:16}}>♥</Text>
          <Text style={styles.emptyT}>Henüz favori eklemediniz</Text>
          <Text style={styles.emptyD}>İçerikleri izlerken ♥ butonuna basın</Text>
        </View>
      ) : (
        <FlatList data={favs} numColumns={3} keyExtractor={i=>i.id} contentContainerStyle={{paddingHorizontal:16}}
          renderItem={({item})=><ContentCard item={item} onPress={open} cardWidth={CARD_W}/>}/>
      )}
      <PlayerModal item={activeItem} visible={playerVisible} onClose={()=>setPlayerVisible(false)}/>
    </View>
  );
}

const styles = StyleSheet.create({
  root:   { flex:1, backgroundColor:C.bg },
  title:  { fontSize:22, fontWeight:'800', color:C.text, margin:16, marginBottom:20 },
  empty:  { flex:1, alignItems:'center', justifyContent:'center', padding:40 },
  emptyT: { fontSize:18, fontWeight:'700', color:C.text2, marginBottom:8 },
  emptyD: { fontSize:14, color:C.text3, textAlign:'center' },
});
