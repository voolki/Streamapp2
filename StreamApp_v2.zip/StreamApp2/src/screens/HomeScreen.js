import React, { useState } from 'react';
import { ScrollView, View, Text, TouchableOpacity, StyleSheet, Dimensions } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { C } from '../theme';
import { TRENDING, ANIME, MUSIC, CONTINUE_WATCHING } from '../data';
import ContentCard from '../components/ContentCard';
import ContinueCard from '../components/ContinueCard';
import PlayerModal from '../components/PlayerModal';

export default function HomeScreen() {
  const insets = useSafeAreaInsets();
  const [activeItem, setActiveItem] = useState(null);
  const [playerVisible, setPlayerVisible] = useState(false);
  const [filter, setFilter] = useState('Hepsi');
  const hero = TRENDING[0];
  const filters = ['Hepsi','Film','Dizi','Anime','Müzik'];
  const open = (item) => { setActiveItem(item); setPlayerVisible(true); };

  return (
    <View style={[styles.root,{paddingTop:insets.top}]}>
      <ScrollView showsVerticalScrollIndicator={false}>

        {/* HERO */}
        <View style={styles.hero}>
          <LinearGradient colors={['#1a0a2e','#0d1b2a','#0a0a0f']} style={StyleSheet.absoluteFill} start={{x:0,y:0}} end={{x:1,y:1}}/>
          <View style={styles.glow}/>
          <View style={styles.heroBadge}><Text style={styles.heroBadgeTxt}>🔥  HAFTANIN ÖNERİSİ</Text></View>
          <View style={styles.heroRow}>
            <View style={{flex:1}}>
              <Text style={styles.heroTitle}>{hero.title.toUpperCase()}</Text>
              <View style={styles.heroMeta}>
                <Text style={styles.heroRat}>★ {hero.rating}</Text>
                <Text style={styles.heroDot}> · </Text>
                <Text style={styles.heroTxt}>{hero.year}</Text>
                <Text style={styles.heroDot}> · </Text>
                <Text style={styles.heroTxt}>{hero.duration}</Text>
              </View>
              <Text style={styles.heroDesc} numberOfLines={3}>{hero.desc}</Text>
              <View style={styles.heroActions}>
                <TouchableOpacity style={styles.btnP} onPress={()=>open(hero)} activeOpacity={0.85}>
                  <Text style={styles.btnPTxt}>▶  İzle</Text>
                </TouchableOpacity>
                <TouchableOpacity style={styles.btnG} activeOpacity={0.85}>
                  <Text style={styles.btnGTxt}>+ Liste</Text>
                </TouchableOpacity>
              </View>
            </View>
            <LinearGradient colors={hero.grad} style={styles.heroPoster} start={{x:0,y:0}} end={{x:1,y:1}}>
              <Text style={{fontSize:50}}>{hero.emoji}</Text>
            </LinearGradient>
          </View>
        </View>

        {/* CONTINUE */}
        <View style={styles.sec}>
          <Text style={styles.secTitle}>Kaldığın <Text style={{color:C.accent}}>Yerden</Text></Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{marginTop:12}}>
            {CONTINUE_WATCHING.map(i=><ContinueCard key={i.id} item={i} onPress={open}/>)}
          </ScrollView>
        </View>

        {/* TRENDING */}
        <View style={styles.sec}>
          <View style={styles.secRow}>
            <Text style={styles.secTitle}>Trend <Text style={{color:C.accent}}>İçerikler</Text></Text>
          </View>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{marginBottom:14}}>
            {filters.map(f=>(
              <TouchableOpacity key={f} style={[styles.pill,filter===f&&styles.pillOn]} onPress={()=>setFilter(f)}>
                <Text style={[styles.pillTxt,filter===f&&{color:'#fff'}]}>{f}</Text>
              </TouchableOpacity>
            ))}
          </ScrollView>
          <ScrollView horizontal showsHorizontalScrollIndicator={false}>
            {TRENDING.map(i=><ContentCard key={i.id} item={i} onPress={open} cardWidth={150}/>)}
          </ScrollView>
        </View>

        {/* ANIME */}
        <View style={styles.sec}>
          <Text style={styles.secTitle}>Anime <Text style={{color:C.accent}}>Önerileri</Text></Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{marginTop:12}}>
            {ANIME.map(i=><ContentCard key={i.id} item={i} onPress={open} cardWidth={140}/>)}
          </ScrollView>
        </View>

        {/* MUSIC */}
        <View style={styles.sec}>
          <Text style={styles.secTitle}>Müzik & <Text style={{color:C.accent}}>Podcast</Text></Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{marginTop:12}}>
            {MUSIC.map(i=><ContentCard key={i.id} item={i} onPress={open} cardWidth={140}/>)}
          </ScrollView>
        </View>

        <View style={{height:20}}/>
      </ScrollView>
      <PlayerModal item={activeItem} visible={playerVisible} onClose={()=>setPlayerVisible(false)}/>
    </View>
  );
}

const styles = StyleSheet.create({
  root:        { flex:1, backgroundColor:C.bg },
  hero:        { padding:20, paddingTop:10, paddingBottom:28, overflow:'hidden' },
  glow:        { position:'absolute', width:300, height:300, borderRadius:150, backgroundColor:'rgba(230,57,70,0.15)', top:-80, left:-60 },
  heroBadge:   { backgroundColor:'rgba(230,57,70,0.18)', alignSelf:'flex-start', paddingHorizontal:12, paddingVertical:5, borderRadius:99, borderWidth:1, borderColor:'rgba(230,57,70,0.35)', marginBottom:14 },
  heroBadgeTxt:{ fontSize:10, fontWeight:'700', color:'#ff6b6b', letterSpacing:0.5 },
  heroRow:     { flexDirection:'row', gap:16, alignItems:'flex-start' },
  heroTitle:   { fontSize:26, fontWeight:'800', color:C.text, lineHeight:30, marginBottom:10 },
  heroMeta:    { flexDirection:'row', alignItems:'center', marginBottom:10 },
  heroRat:     { fontSize:13, color:C.gold, fontWeight:'700' },
  heroDot:     { color:C.text3 },
  heroTxt:     { fontSize:12, color:C.text2 },
  heroDesc:    { fontSize:13, color:C.text2, lineHeight:20, marginBottom:18 },
  heroActions: { flexDirection:'row', gap:10 },
  btnP:        { backgroundColor:C.accent, paddingHorizontal:18, paddingVertical:11, borderRadius:10 },
  btnPTxt:     { color:'#fff', fontWeight:'700', fontSize:13 },
  btnG:        { backgroundColor:'rgba(255,255,255,0.08)', paddingHorizontal:16, paddingVertical:11, borderRadius:10, borderWidth:1, borderColor:C.border },
  btnGTxt:     { color:C.text, fontWeight:'600', fontSize:13 },
  heroPoster:  { width:110, height:155, borderRadius:14, alignItems:'center', justifyContent:'center' },
  sec:         { paddingHorizontal:16, marginBottom:28 },
  secRow:      { flexDirection:'row', justifyContent:'space-between', alignItems:'center', marginBottom:14 },
  secTitle:    { fontSize:18, fontWeight:'700', color:C.text, marginBottom:14 },
  pill:        { paddingHorizontal:16, paddingVertical:8, borderRadius:99, borderWidth:1, borderColor:C.border, backgroundColor:C.surface, marginRight:8 },
  pillOn:      { backgroundColor:C.accent, borderColor:C.accent },
  pillTxt:     { fontSize:12, color:C.text2, fontWeight:'500' },
});
