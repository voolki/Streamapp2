import React, { useState } from 'react';
import { View, Text, FlatList, TouchableOpacity, StyleSheet } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { C } from '../theme';
import { PLUGINS } from '../data';

export default function PluginsScreen() {
  const insets = useSafeAreaInsets();
  const [plugins, setPlugins] = useState(PLUGINS);
  const toggle = (id) => setPlugins(prev => prev.map(p => p.id===id ? {...p,active:!p.active} : p));

  return (
    <View style={[styles.root,{paddingTop:insets.top}]}>
      <Text style={styles.title}>Plugin <Text style={{color:C.accent}}>Yönetimi</Text></Text>
      <Text style={styles.sub}>{plugins.filter(p=>p.active).length} aktif kaynak</Text>
      <FlatList data={plugins} keyExtractor={i=>i.id} contentContainerStyle={{paddingHorizontal:16}}
        showsVerticalScrollIndicator={false}
        renderItem={({item})=>(
          <View style={[styles.card,item.active&&styles.cardOn]}>
            <Text style={styles.icon}>{item.icon}</Text>
            <View style={{flex:1}}>
              <Text style={styles.name}>{item.name}</Text>
              <Text style={styles.desc}>{item.desc}</Text>
              <Text style={styles.count}>{item.count}</Text>
            </View>
            <TouchableOpacity style={[styles.toggle,item.active&&styles.toggleOn]} onPress={()=>toggle(item.id)}>
              <View style={[styles.thumb,item.active&&styles.thumbOn]}/>
            </TouchableOpacity>
          </View>
        )}/>
    </View>
  );
}

const styles = StyleSheet.create({
  root:     { flex:1, backgroundColor:C.bg },
  title:    { fontSize:22, fontWeight:'800', color:C.text, margin:16, marginBottom:4 },
  sub:      { fontSize:13, color:C.text3, marginHorizontal:16, marginBottom:20 },
  card:     { flexDirection:'row', alignItems:'center', backgroundColor:C.surface, borderRadius:12, padding:14, marginBottom:10, borderWidth:1, borderColor:C.border, gap:12 },
  cardOn:   { borderColor:'rgba(230,57,70,0.3)' },
  icon:     { fontSize:28, width:36, textAlign:'center' },
  name:     { fontSize:14, fontWeight:'700', color:C.text, marginBottom:2 },
  desc:     { fontSize:12, color:C.text2, marginBottom:2 },
  count:    { fontSize:11, color:C.text3 },
  toggle:   { width:46, height:26, borderRadius:99, backgroundColor:C.bg3, justifyContent:'center', paddingHorizontal:3 },
  toggleOn: { backgroundColor:C.accent },
  thumb:    { width:20, height:20, borderRadius:10, backgroundColor:'#fff', alignSelf:'flex-start' },
  thumbOn:  { alignSelf:'flex-end' },
});
