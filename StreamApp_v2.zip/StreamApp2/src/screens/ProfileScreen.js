import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet, ScrollView, Alert } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { C } from '../theme';

const SETTINGS = [
  {icon:'🎬',label:'Video Kalitesi',value:'1080p Auto'},
  {icon:'🌙',label:'Tema',value:'Karanlık'},
  {icon:'🔔',label:'Bildirimler',value:'Açık'},
  {icon:'📥',label:'İndirme Kalitesi',value:'720p'},
  {icon:'🌐',label:'Dil',value:'Türkçe'},
  {icon:'⬆️',label:'Uygulama Hakkında',value:'v1.0.0'},
];

export default function ProfileScreen() {
  const insets = useSafeAreaInsets();
  return (
    <ScrollView style={[styles.root,{paddingTop:insets.top}]} showsVerticalScrollIndicator={false}>
      <LinearGradient colors={['#1a0a2e','#0d1b2a']} style={styles.card} start={{x:0,y:0}} end={{x:1,y:1}}>
        <View style={styles.avatar}><Text style={styles.avatarTxt}>K</Text></View>
        <View>
          <Text style={styles.uName}>Kullanıcı</Text>
          <Text style={styles.uMail}>kullanici@mail.com</Text>
          <View style={styles.plan}><Text style={styles.planTxt}>✦ Ücretsiz Plan</Text></View>
        </View>
      </LinearGradient>

      <View style={styles.stats}>
        {[['🎬','48','İzlendi'],['♥','12','Favori'],['↓','3','İndirildi']].map(([ic,v,lb])=>(
          <View key={lb} style={styles.stat}>
            <Text style={{fontSize:20,marginBottom:4}}>{ic}</Text>
            <Text style={styles.statV}>{v}</Text>
            <Text style={styles.statL}>{lb}</Text>
          </View>
        ))}
      </View>

      <Text style={styles.secLabel}>AYARLAR</Text>
      <View style={styles.settingsList}>
        {SETTINGS.map((s,i)=>(
          <TouchableOpacity key={i} style={[styles.row,i===SETTINGS.length-1&&{borderBottomWidth:0}]}
            onPress={()=>Alert.alert(s.label, s.value||'Yakında gelecek')}>
            <Text style={styles.rowIcon}>{s.icon}</Text>
            <Text style={styles.rowLabel}>{s.label}</Text>
            {s.value?<Text style={styles.rowValue}>{s.value}</Text>:null}
            <Text style={styles.chevron}>›</Text>
          </TouchableOpacity>
        ))}
      </View>
      <View style={{height:30}}/>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  root:         { flex:1, backgroundColor:C.bg },
  card:         { margin:16, borderRadius:16, padding:20, flexDirection:'row', alignItems:'center', gap:16 },
  avatar:       { width:64, height:64, borderRadius:32, backgroundColor:C.accent, alignItems:'center', justifyContent:'center' },
  avatarTxt:    { fontSize:26, fontWeight:'800', color:'#fff' },
  uName:        { fontSize:20, fontWeight:'700', color:C.text },
  uMail:        { fontSize:13, color:C.text2, marginTop:2 },
  plan:         { backgroundColor:'rgba(244,162,97,0.2)', borderWidth:1, borderColor:C.gold, alignSelf:'flex-start', paddingHorizontal:10, paddingVertical:3, borderRadius:99, marginTop:8 },
  planTxt:      { fontSize:11, color:C.gold, fontWeight:'600' },
  stats:        { flexDirection:'row', marginHorizontal:16, backgroundColor:C.surface, borderRadius:14, marginBottom:24, borderWidth:1, borderColor:C.border },
  stat:         { flex:1, alignItems:'center', padding:16 },
  statV:        { fontSize:20, fontWeight:'800', color:C.text },
  statL:        { fontSize:11, color:C.text3, marginTop:2 },
  secLabel:     { fontSize:11, fontWeight:'700', color:C.text3, marginHorizontal:16, marginBottom:8, letterSpacing:1 },
  settingsList: { marginHorizontal:16, backgroundColor:C.surface, borderRadius:14, borderWidth:1, borderColor:C.border, overflow:'hidden' },
  row:          { flexDirection:'row', alignItems:'center', padding:14, borderBottomWidth:1, borderBottomColor:C.border, gap:12 },
  rowIcon:      { fontSize:18, width:28 },
  rowLabel:     { flex:1, fontSize:14, color:C.text },
  rowValue:     { fontSize:13, color:C.text3 },
  chevron:      { fontSize:20, color:C.text3 },
});
