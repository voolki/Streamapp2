import React, { useState, useMemo } from 'react';
import { View, Text, TextInput, FlatList, StyleSheet, TouchableOpacity, Dimensions } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { C } from '../theme';
import { TRENDING, ANIME, MUSIC } from '../data';
import ContentCard from '../components/ContentCard';
import PlayerModal from '../components/PlayerModal';

const ALL = [...TRENDING,...ANIME,...MUSIC];
const { width } = Dimensions.get('window');
const CARD_W = (width - 48) / 3;

export default function SearchScreen() {
  const insets = useSafeAreaInsets();
  const [q, setQ] = useState('');
  const [cat, setCat] = useState('Tümü');
  const [activeItem, setActiveItem] = useState(null);
  const [playerVisible, setPlayerVisible] = useState(false);
  const cats = ['Tümü','Film','Dizi','Anime','Müzik'];

  const results = useMemo(() => ALL.filter(i => {
    const mQ = !q || i.title.toLowerCase().includes(q.toLowerCase());
    const mC = cat==='Tümü' || i.genre.toLowerCase().includes(cat.toLowerCase());
    return mQ && mC;
  }), [q, cat]);

  const open = (item) => { setActiveItem(item); setPlayerVisible(true); };

  return (
    <View style={[styles.root,{paddingTop:insets.top}]}>
      <View style={styles.searchWrap}>
        <Text style={styles.sIcon}>⌕</Text>
        <TextInput style={styles.input} placeholder="Film, dizi, anime ara..." placeholderTextColor={C.text3} value={q} onChangeText={setQ}/>
        {q.length>0 && <TouchableOpacity onPress={()=>setQ('')}><Text style={{color:C.text3,fontSize:18,paddingHorizontal:8}}>✕</Text></TouchableOpacity>}
      </View>
      <View style={{paddingHorizontal:16,marginBottom:16}}>
        <FlatList data={cats} horizontal showsHorizontalScrollIndicator={false} keyExtractor={i=>i}
          renderItem={({item})=>(
            <TouchableOpacity style={[styles.pill,cat===item&&styles.pillOn]} onPress={()=>setCat(item)}>
              <Text style={[styles.pillTxt,cat===item&&{color:'#fff',fontWeight:'600'}]}>{item}</Text>
            </TouchableOpacity>
          )}/>
      </View>
      <FlatList data={results} numColumns={3} keyExtractor={i=>i.id} contentContainerStyle={{paddingHorizontal:16}}
        showsVerticalScrollIndicator={false}
        ListHeaderComponent={<Text style={{fontSize:12,color:C.text3,marginBottom:12}}>{results.length} içerik</Text>}
        renderItem={({item})=><ContentCard item={item} onPress={open} cardWidth={CARD_W}/>}/>
      <PlayerModal item={activeItem} visible={playerVisible} onClose={()=>setPlayerVisible(false)}/>
    </View>
  );
}

const styles = StyleSheet.create({
  root:       { flex:1, backgroundColor:C.bg },
  searchWrap: { flexDirection:'row', alignItems:'center', margin:16, backgroundColor:C.surface, borderRadius:99, borderWidth:1, borderColor:C.border, paddingHorizontal:16 },
  sIcon:      { color:C.text3, fontSize:18, marginRight:8 },
  input:      { flex:1, color:C.text, fontSize:14, paddingVertical:12 },
  pill:       { paddingHorizontal:16, paddingVertical:8, borderRadius:99, borderWidth:1, borderColor:C.border, backgroundColor:C.surface, marginRight:8 },
  pillOn:     { backgroundColor:C.accent, borderColor:C.accent },
  pillTxt:    { fontSize:12, color:C.text2 },
});
