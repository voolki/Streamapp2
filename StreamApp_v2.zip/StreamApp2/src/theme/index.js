export const C = {
  bg:      '#0a0a0f',
  bg2:     '#111118',
  bg3:     '#1a1a24',
  surface: '#16161f',
  border:  'rgba(255,255,255,0.07)',
  accent:  '#e63946',
  gold:    '#f4a261',
  text:    '#f0f0f5',
  text2:   '#8888a0',
  text3:   '#555568',
};
